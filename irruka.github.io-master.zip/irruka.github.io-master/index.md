# HTML5 from a doc perspective

## The similarities between XML and HTML
__XML__ and __HTML__ are both markup languages:

* General syntax is somewhat similar - both use tags
* Both do nothing on their on

## The Difference Between XML and HTML
__XML__ and __HTML__ were designed with different goals:

* _XML_ was designed to carry data - with focus on what data is
* _HTML_ was designed to display data - with focus on how data looks
* _XML_ tags are not predefined like HTML tags are
* test content goes here
* moooore test content
[Tutorila 1](old_index.md)

